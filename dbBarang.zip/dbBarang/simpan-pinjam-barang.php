<?php
if (isset($_POST['submit'])){
include "koneksi.php";

$id_barang=$_POST["id_barang"];
$id_users=$_POST["id_users"];
$nama_barang=$_POST["nama_barang"];
$peminjam=$_POST["peminjam"];
$nama_pengembali=$_POST["nama_pengembali"];
$tgl_pinjam=$_POST["tgl_pinjam"];
$tgl_kembali=$_POST["tgl_kembali"];
$keterangan=$_POST["keterangan"];

if (empty($_POST['id_barang']) || empty($_POST['id_users']) || empty($_POST['nama_barang']) || empty($_POST['peminjam']) || empty($_POST['nama_pengembali'])|| empty($_POST['tgl_pinjam']) || empty($_POST['tgl_kembali']) || empty($_POST['keterangan']))
{
    echo "Isi kolom yang masih kosong!";
}
else {

$sql="insert into tbl_transaksi (id_barang, id_users, nama_barang, peminjam, nama_pengembali, tgl_pinjam, tgl_kembali, keterangan)
values ('$id_barang', '$id_users', '$nama_barang', '$peminjam', '$nama_pengembali', '$tgl_pinjam', '$tgl_kembali', '$keterangan')";

$hasil=mysqli_query($db,$sql);
}
}
?>