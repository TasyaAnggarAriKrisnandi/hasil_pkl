<!DOCTYPE html>
<html>
<head>
 <title>Sistem Pencatatan Keluar Masuk Barang MIS System</title>
 <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<hr>

<div class="menu">
<ul id="navigasi">
 <li><a href="index.php">Home</a></li>
 <li><a href="tabel_barang.php">Daftar Barang</a></li>
 <li><a href="tabel_pinjam.php">Peminjam Barang</a></li>
 </li>
</ul>
</div>