<?php

if (isset($_POST['submit'])){


$nama_barang=$_POST['nama_barang'];
$stok_barang=$_POST['stok_barang'];

if (empty($_POST['nama_barang']) || empty($_POST['stok_barang']))
{
    echo "Isi kolom yang masih kosong!";
}
else {

include 'koneksi.php';

$sql="insert into tbl_barang(id_barang, nama_barang, stok_barang, created_at) 
value ('0','$nama_barang','$stok_barang', NOW())";

$res=mysqli_query($db, $sql);

if (!$res){
echo"Request gagal di buat";
}
else{
    echo "Input barang berhasil"; 
}
}
}
?>