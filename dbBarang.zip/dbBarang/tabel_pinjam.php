<?php 
include 'header.php';
?>

<body style="text-align:center">
 <h1>Tabel Data Pinjam</h1><hr />
 <a href="form_pinjam.php" class="btn btn-danger pull-right"><i class="fa fa-plus"></i>Tambah</a>
 <table style="width:100%" class="table1">
  <tr>
    <th>No</th>
    <th>No Barang</th>
    <th>No Users</th>
    <th>Nama Barang</th>
    <th>Peminjam</th>
    <th>Nama Pengembali</th>
    <th>Tanggal Pinjam</th>
    <th>Tanggal Kembali</th>
    <th>Keterangan</th>
    <th>create_at</th>
    <th>update_at</th>


    <?php
 include 'koneksi.php';

  $no = 1;
  $data = mysqli_query($db,"select * from tbl_transaksi");
  while($r = mysqli_fetch_array($data)){
   $id = $r['id'];
   $id_barang = $r['id_barang'];
   $id_users = $r['id_users'];
   $nama_barang = $r['nama_barang'];
   $peminjam = $r['peminjam'];
   $nama_pengembali = $r['nama_pengembali'];
   $tgl_pinjam = $r['tgl_pinjam'];
   $tgl_kembali = $r['tgl_kembali'];
   $keterangan = $r['keterangan'];
   $create_at = $r['create_at'];
   $update_at = $r['update_at'];
        ?>
        <tr>
          <td><?php echo $id; ?></td>
          <td><?php echo $id_barang; ?></td>
          <td><?php echo $id_users; ?></td>
          <td><?php echo $nama_barang; ?></td>
          <td><?php echo $peminjam; ?></td>
          <td><?php echo $nama_pengembali; ?></td>
          <td><?php echo $tgl_pinjam; ?></td>
          <td><?php echo $tgl_kembali; ?></td>
          <td><?php echo $keterangan; ?></td>
          <td><?php echo $create_at; ?></td>
          <td><?php echo $update_at; ?></td>

        </tr>
        <?php 
  }
  ?>
</table>
</body>
</html>
</body>
</html>