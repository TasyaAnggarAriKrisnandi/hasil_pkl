<?php 
include 'header.php';
?>

<body style="text-align:center">
 <h1>Tabel Data Barang</h1><hr />
 <a href="daftar_barang.php" class="btn btn-danger pull-right"><i class="fa fa-plus"></i>Tambah</a>
 <table style="width:100%" class="table1">
  <tr>
    <th>No</th>
    <th>Nama Barang</th>
    <th>Stok Barang</th>
    <th>created_at</th>
    <th>update_at</th>

    <?php
 include 'koneksi.php';

  $no = 1;
  $data = mysqli_query($db,"select * from tbl_barang");
  while($r = mysqli_fetch_array($data)){
   $id_barang = $r['id_barang'];
   $nama_barang= $r['nama_barang'];
   $stok_barang = $r['stok_barang'];
   $created_at = $r['created_at'];
   $update_at = $r['update_at'];
        ?>
        <tr>
          <td><?php echo $id_barang; ?></td>
          <td><?php echo $nama_barang; ?></td>
          <td><?php echo $stok_barang; ?></td>
          <td><?php echo $created_at; ?></td>
          <td><?php echo $update_at; ?></td>
        </tr>
        <?php 
  }
  ?>
</table>
</body>
</html>
</body>
</html>