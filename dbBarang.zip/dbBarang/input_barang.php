<?php 
include 'header.php';
?>

<form action="input.php" method="POST">

<div class="row">
<div class="col-xs-1"></div>
<div class="col-xs-4 well well-lg">
 <h2 align="center">Form Input Barang</h2>

<table>

    <tr>
        <td>Nama Barang</td>
        <td>:</td>
        <td><input type="varchar" name="nama_barang"/></td>
    </tr>

    <tr>
        <td>Stok Barang</td>
        <td>:</td>
        <td><input type="varchar" name="stok_barang"/></td>
    </tr>
    
    <tr>
        <td><input type="submit" name="submit" value="SAVE"/></td>
        <td></td>
        <td></td>
    </tr>

      </form>
    </table>
  </div>
</div>
</body>
</html>