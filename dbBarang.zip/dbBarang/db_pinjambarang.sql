-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 24, 2022 at 10:22 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pinjambarang`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_barang`
--

CREATE TABLE `tbl_barang` (
  `id_barang` int(11) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `stok_barang` int(11) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `update_at` datetime(6) DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_barang`
--

INSERT INTO `tbl_barang` (`id_barang`, `nama_barang`, `stok_barang`, `created_at`, `update_at`) VALUES
(1, '0', 0, '2022-08-24 09:10:58.007632', NULL),
(9, '0', 0, '0000-00-00 00:00:00.000000', '2022-08-24 10:36:40.994902'),
(10, '0', 0, '0000-00-00 00:00:00.000000', '2022-08-24 10:36:41.287181'),
(11, '0', 0, '0000-00-00 00:00:00.000000', '2022-08-24 10:36:42.650871'),
(45, 'Laptop', 2, '0000-00-00 00:00:00.000000', '2022-08-24 10:51:10.341737'),
(46, 'Laptop', 2, '0000-00-00 00:00:00.000000', '2022-08-24 10:51:40.443070'),
(47, 'Laptop', 2, '0000-00-00 00:00:00.000000', '2022-08-24 10:52:00.525891'),
(48, 'Laptop', 2, '0000-00-00 00:00:00.000000', '2022-08-24 10:52:13.786315'),
(49, 'Laptop', 2, '0000-00-00 00:00:00.000000', '2022-08-24 10:54:07.052766'),
(50, 'Laptop', 2, '0000-00-00 00:00:00.000000', '2022-08-24 10:54:07.500094'),
(51, 'Laptop', 2, '0000-00-00 00:00:00.000000', '2022-08-24 10:54:07.681977'),
(52, 'Laptop', 2, '0000-00-00 00:00:00.000000', '2022-08-24 10:54:07.820668'),
(53, 'Laptop', 2, '0000-00-00 00:00:00.000000', '2022-08-24 10:54:07.997167'),
(54, 'Laptop', 2, '0000-00-00 00:00:00.000000', '2022-08-24 10:54:08.115666'),
(55, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 10:54:13.716191'),
(56, 'Laptop', 2, '0000-00-00 00:00:00.000000', '2022-08-24 10:54:21.653336'),
(57, 'Laptop', 2, '0000-00-00 00:00:00.000000', '2022-08-24 10:56:14.502022'),
(58, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 10:56:15.852489'),
(59, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 10:56:22.400734'),
(60, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 10:56:24.350296'),
(61, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 10:56:24.777716'),
(62, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 10:56:24.922691'),
(63, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 10:56:25.095575'),
(64, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 10:56:25.860744'),
(65, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:00:46.492446'),
(66, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:00:47.623234'),
(67, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:00:48.277533'),
(68, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:04:40.436127'),
(69, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:04:41.837847'),
(70, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:04:42.762927'),
(71, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:05:32.328399'),
(72, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:05:34.453185'),
(73, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:05:42.907551'),
(74, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:06:07.687312'),
(75, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:13:01.612077'),
(76, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:13:26.243776'),
(77, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:14:07.797442'),
(78, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:14:51.210941'),
(79, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:15:25.142122'),
(80, '', 0, '0000-00-00 00:00:00.000000', '2022-08-24 11:15:26.330795'),
(82, 'Laptop', 2, '0000-00-00 00:00:00.000000', '2022-08-24 11:23:36.626936'),
(83, 'Laptop', 3, '0000-00-00 00:00:00.000000', '2022-08-24 14:16:27.257670'),
(84, 'Laptop', 3, '0000-00-00 00:00:00.000000', '2022-08-24 14:16:35.576639'),
(85, 'Laptop', 4, '0000-00-00 00:00:00.000000', '2022-08-24 14:30:56.910209'),
(86, 'Laptop', 4, '0000-00-00 00:00:00.000000', '2022-08-24 14:45:46.415266'),
(87, 'Laptop', 2, '0000-00-00 00:00:00.000000', '2022-08-24 14:55:11.766937'),
(88, 'Laptop', 3, '0000-00-00 00:00:00.000000', '2022-08-24 14:57:58.603328'),
(89, 'Laptop', 4, '0000-00-00 00:00:00.000000', '2022-08-24 15:01:06.740295'),
(90, 'Laptop', 4, '2022-08-24 15:02:45.000000', '2022-08-24 15:02:45.379502'),
(91, 'Laptop', 3, '2022-08-24 15:02:52.000000', '2022-08-24 15:02:52.974393');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transaksi`
--

CREATE TABLE `tbl_transaksi` (
  `id` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `id_users` int(11) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `peminjam` varchar(255) NOT NULL,
  `nama_pengembali` varchar(255) NOT NULL,
  `tgl_pinjam` datetime NOT NULL,
  `tgl_kembali` datetime NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `create_at` datetime(6) NOT NULL,
  `update_at` datetime(6) DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_transaksi`
--

INSERT INTO `tbl_transaksi` (`id`, `id_barang`, `id_users`, `nama_barang`, `peminjam`, `nama_pengembali`, `tgl_pinjam`, `tgl_kembali`, `keterangan`, `create_at`, `update_at`) VALUES
(1, 0, 0, 'SSI-NB-018', 'admin', 'admin', '2016-11-23 00:00:00', '2016-11-23 00:00:00', 'lengkap', '2022-08-24 08:45:25.000000', NULL),
(2, 0, 0, 'Laptop', 'admin', 'admin', '2022-08-24 00:00:00', '2022-08-24 00:00:00', 'lengkap', '0000-00-00 00:00:00.000000', '2022-08-24 13:10:06.171644');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_users` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `create_at` datetime(6) NOT NULL,
  `update_at` datetime(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_users`, `nama`, `password`, `section`, `create_at`, `update_at`) VALUES
(1, 'admin', '123', 'mis', '2022-08-24 10:23:09.610976', '2022-08-24 10:18:27.242140');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_barang`
--
ALTER TABLE `tbl_barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `tbl_transaksi`
--
ALTER TABLE `tbl_transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_users`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_barang`
--
ALTER TABLE `tbl_barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `tbl_transaksi`
--
ALTER TABLE `tbl_transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_users` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
