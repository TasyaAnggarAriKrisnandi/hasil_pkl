<!DOCTYPE html>
<html>
<head>
 <title>Sistem Pencatatan Keluar Masuk Barang MIS System</title>
 <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<hr>

<div class="menu">
<ul id="navigasi">
 <li><a href="index.php">Home</a></li>
 <li><a href="tabel_barang.php">Daftar Barang</a></li>
 <li><a href="tabel_pinjam.php">Peminjam Barang</a></li>
 </li>
</ul>
</div>

<form action="simpan-pinjam-barang.php" method="POST">

<div class="row">
<div class="col-xs-1"></div>
<div class="col-xs-4 well well-lg">
 <h2 align="center">Form Input Pinjam Barang</h2>

<table>

    <tr>
        <td>No Barang</td>
        <td>:</td>
        <td><input type="varchar" name="id_barang"/></td>
    </tr>

    <tr>
        <td>No Users</td>
        <td>:</td>
        <td><input type="varchar" name="id_Users"/></td>
    </tr>

    <tr>
        <td>Nama Barang</td>
        <td>:</td>
        <td><input type="varchar" name="nama_barang"/></td>
    </tr>

    <tr>
        <td>Peminjam</td>
        <td>:</td>
        <td><input type="varchar" name="peminjam"/></td>
    </tr>

    <tr>
        <td>Nama Pengembali</td>
        <td>:</td>
        <td><input type="varchar" name="nama_pengembali"/></td>
    </tr>

    <tr>
        <td>Tanggal Pinjam</td>
        <td>:</td>
        <td><input type="date" name="tgl_pinjam"/></td>
    </tr>

    <tr>
        <td>Tanggal Kembali</td>
        <td>:</td>
        <td><input type="date" name="tgl_kembali"/></td>
    </tr>

    <tr>
        <td>Keterangan</td>
        <td>:</td>
        <td><input type="varchar" name="keterangan"/></td>
    </tr>

    <tr>
        <td><input type="submit" name="submit" value="SAVE"/></td>
        <td></td>
        <td></td>
    </tr>

      </form>
    </table>
  </div>
</div>
</body>
</html>
        
        
        
